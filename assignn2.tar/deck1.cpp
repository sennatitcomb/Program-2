#include "deck1.h"

/*************************************************************************************************************************************
** Function: Default constructor 
** Description: makes deck of cards
** Parameters: (no arguements)
** Pre-conditions: (no arguements)
** Post-conditions: deck is created and number of cards is set to 52
*************************************************************************************************************************************/
Deck::Deck() {
    int k = 0;
    for (int j = 1; j < 5; j++) {
        for(int i = 1; i < 14; i++) {
            cards[k] = Card(i, j);
            k++;
        }
    }
    n_cards = 52;
}


/*************************************************************************************************************************************
** Function: Destructor
** Description: destroys object
** Parameters: (no arguements)
** Pre-conditions: (no arguements)
** Post-conditions: Delete from stack
*************************************************************************************************************************************/
Deck::~Deck() {
    //cout << " Deck Destructor!\n";
} 

/*************************************************************************************************************************************
** Function: putTop
** Description: new card is placed at top
** Parameters: Card card
** Pre-conditions: Card
** Post-conditions: puts card at top of deck
*************************************************************************************************************************************/
void Deck::putTop(Card card)
{
  	cards[n_cards].set_rank(card.get_rank());
    cards[n_cards].set_suit(card.get_suit());
    ++n_cards;
}

/*************************************************************************************************************************************
** Function: get_deck()
** Description: returns deck of cards
** Parameters: (no arguements)
** Pre-conditions: (no arguements)
** Post-conditions: return this-> cards
*************************************************************************************************************************************/
Card* Deck::get_deck() {
    return this-> cards;
        //use this-> to point to variable in class

    //here I will be creating the deck of cards
 //here you are going into cards class and calling function
    
}

/*************************************************************************************************************************************
** Function: shuffle()
** Description: shuffles the deck of cards
** Parameters: (no arguements)
** Pre-conditions: (no arguements)
** Post-conditions: creates shuffled deck
*************************************************************************************************************************************/
void Deck::shuffle() {
   srand (time(NULL));
    for(int i = 0; i < 52; i++) {
        int x = rand()%52;
        Card temp = cards[i];
        cards[i] = cards[x];
        cards[x] = temp;

    }
    //here I will be randomly generating the cards
}
 
/*************************************************************************************************************************************
** Function: printTopCard()
** Description: returns the top card from the deck
** Parameters: (no arguements)
** Pre-conditions: (no arguements)
** Post-conditions: gives card off top of deck
*************************************************************************************************************************************/
void Deck::printTopCard() {
    if (cards[n_cards-1].get_rank() != 0) {
            cout << "The top card is ";
            cout << cards[n_cards-1].getrankstr() << " of " <<  cards[n_cards-1].getsuitstr()<< endl;
    }
} 
 
/*************************************************************************************************************************************
** Function: topcard()
** Description: gives top card
** Parameters: (no arguements)
** Pre-conditions: (no arguements)
** Post-conditions: return cards[n_cards];
*************************************************************************************************************************************/
Card Deck::topcard() {
     --n_cards; // One less card on the deck
    return cards[n_cards];
} 

/*************************************************************************************************************************************
** Function: copyCard()
** Description: makes a copy of the card
** Parameters: (no arguements)
** Pre-conditions: (no arguements)
** Post-conditions: return cards[n_cards-1];
*************************************************************************************************************************************/
Card Deck::copyCard() {
    return cards[n_cards-1];
}

/*************************************************************************************************************************************
** Function: getncards()
** Description: gives # of cards
** Parameters: (no arguements)
** Pre-conditions: (no arguements)
** Post-conditions: return n_cards;
*************************************************************************************************************************************/
int Deck::getncards() {
    --n_cards;
    return n_cards;
}

/*************************************************************************************************************************************
** Function: get_cardrank()
** Description: gives top card
** Parameters: int x
** Pre-conditions: int
** Post-conditions: return card rank;
*************************************************************************************************************************************/
string Deck::get_cardrank(int x) {
    return cards[x].getrankstr();
} 
 
/*************************************************************************************************************************************
** Function: get_suitstr()
** Description: gives top card
** Parameters: int x
** Pre-conditions: int
** Post-conditions: return cards[n_cards];
*************************************************************************************************************************************/
string Deck::get_cardsuit(int x) {
    return cards[x].getsuitstr();
}

/*************************************************************************************************************************************
** Function: printdeck()
** Description: prints the deck of cards
** Parameters: (no arguements)
** Pre-conditions: (no arguements)
** Post-conditions: prints cards
*************************************************************************************************************************************/
void Deck::printdeck(){
    for(int i = 0; i < 52; i++) {
        //cout << cards[i].getrankstr() << " of " <<  cards[i].getsuitstr()<< endl;
        //if (cards[i].get_rank() > 1 and cards[i].get_rank() < 11) {
        //    cout << setw(2) << i+1 << " : " << cards[i].get_rank() << " of " <<  cards[i].getsuitstr()<< endl;
        //} else if (cards[i].get_rank() == 0) {
        //    //do nothing
        //} else {
            cout << setw(2) << i+1 << ". " << cards[i].getrankstr() << " of " <<  cards[i].getsuitstr()<< endl;
        //}
    }
    //here I will be printing the deck of cards out
}
