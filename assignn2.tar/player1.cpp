#include "player1.h"

Player::Player() {
   this->name = "";
}

/*************************************************************************************************************************************
** Function: Non-default constructor
** Description: variable string is set
** Parameters: string name
** Pre-conditions: string name
** Post-conditions: this->name is set to name
*************************************************************************************************************************************/
Player::Player(string name){
   this->name = name;
}

/*************************************************************************************************************************************
** Function: getName()
** Description: name is returned
** Parameters: none
** Pre-conditions: name is set
** Post-conditions: return name
*************************************************************************************************************************************/
string Player::getName() {
        return name;
    };

/*************************************************************************************************************************************
** Function: printHand()
** Description: the hand is printed
** Parameters: none
** Pre-conditions: none
** Post-conditions: prints hand of player
*************************************************************************************************************************************/
void Player::printHand() {
        hand.print();
 };

/*************************************************************************************************************************************
** Function: get_rank()
** Description: the card from the player hand is given
** Parameters: int x
** Pre-conditions: int
** Post-conditions: prints rank of card
*************************************************************************************************************************************/
string Player::get_rank(int x) {
      string rank;
      rank = hand.get_cardrank(x);
      return rank;
}

/*************************************************************************************************************************************
** Function: get_suit()
** Description: the card from the player hand is given
** Parameters: int x
** Pre-conditions: int
** Post-conditions: prints rank of card
*************************************************************************************************************************************/
string Player::get_suit(int x) {
      string suit;
      suit = hand.get_cardsuit(x);
      return suit;
}

/*************************************************************************************************************************************
** Function: numberofcards()
** Description: Returns x
** Parameters: none
** Pre-conditions: n_cards has been declares
** Post-conditions: number of cards is given
*************************************************************************************************************************************/
 int Player::numberofcards() {
      int x = 0;
      x = hand.numberofcards();
      return x;
 }

/*************************************************************************************************************************************
** Function: removeCard
** Description: takes card from hand
** Parameters: int cardIndex
** Pre-conditions: int
** Post-conditions: no b/c void
*************************************************************************************************************************************/
void Player::removeCard(int cardIndex) {
      hand.removeCard(cardIndex);
}

/*************************************************************************************************************************************
** Function: getCard
** Description: gets card from hand
** Parameters: int cardIndex
** Pre-conditions: int
** Post-conditions: return hand.getCard(cardIndex);
*************************************************************************************************************************************/
Card Player::getCard(int cardIndex) {
      return hand.getCard(cardIndex);
}

/*************************************************************************************************************************************
** Function: addCard
** Description: card is added to hand of player
** Parameters: Card card
** Pre-conditions: Card
** Post-conditions: player's hand increases by a card
*************************************************************************************************************************************/
void Player::addCard(Card card)
{
   // << "Player::addCard ";
   //card.print();
   hand.addCard(card); 

} // End of getCard()


/*************************************************************************************************************************************
** Function: isHuman
** Description: accessor
** Parameters: none
** Pre-conditions: none
** Post-conditions: return this->humanFlag
*************************************************************************************************************************************/
bool Player::isHuman() {
   return this->humanFlag;
}
/*************************************************************************************************************************************
** Function: isComputer
** Description: accessor
** Parameters: none
** Pre-conditions: none
** Post-conditions: return ! this->humanFlag
*************************************************************************************************************************************/
bool Player::isComputer() {
   return ! this->humanFlag;
}
/*************************************************************************************************************************************
** Function: setHuman
** Description: mutator
** Parameters: none
** Pre-conditions: none
** Post-conditions: none
*************************************************************************************************************************************/
void Player::setHuman() {
   this->humanFlag = true;
}
/*************************************************************************************************************************************
** Function: setComputer
** Description: mutator
** Parameters: none
** Pre-conditions: none
** Post-conditions: none
*************************************************************************************************************************************/
void Player::setComputer() {
   this->humanFlag = false;
}