#ifndef DECK1_H
#define DECK1_H

#include <iostream>
#include <stdlib.h>
#include <string>
#include <cmath>
#include <cstring>
#include <ctime>
#include <fstream>
#include <iomanip>
#include <algorithm>
#include "cards1.h"
#include "hand1.h"

using namespace std;

class Deck {
  private:
    Card cards[52];
    int n_cards;  // Number of cards remaining in the deck.
    Card topCard;
  public:

    Deck(); // Default constructor (no arguements)
    Deck(int); //Non-default constructor (takes cards)
    ~Deck();
    Card* get_deck(); //Accessor
    void set_deck(); //Mutator
    void shuffle();
    void printdeck();
    void printTopCard();
    Card topcard();
    Card gettopcard();
    void settopcard();
    int getncards();
    string get_cardrank(int);
    string get_cardsuit(int);
    void putTop(Card card);
    Card copyCard();
  // must have constructors, destructor, accessor methods, and mutator methods

};

#endif
