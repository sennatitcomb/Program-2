/******************************************************
** Program: crazyeights.cpp
** Author: Senna Titcomb
** Date: 04/26/2020
** Description: Allows a user to play a game of Crazy Eights with a computer. 
** Each player will be dealt 7 random cards and each player will take turns placing a card of the same rank or suit atop the other. 
** If a player is unable to make their move, they will draw until they reach a valid card or until the whole deck is drawn.
** The game ends when either the whole deck is drawn and nobody can play (the player with less cards will win) or a player has no more cards in their hand.
** Input: the chosen card, the choice to play again, and if prompted, the new suit after the wild card
** Output: the original deck, the player’s cards, the cards at the top of the pile, the winner, and the question to play again
******************************************************/
#include "cards1.h"
#include "deck1.h"
#include "hand1.h"
#include "player1.h"
#include "game1.h"


int main() {
    Deck theDeck;
    Game theGame( theDeck );
    Player person("Person");
    person.setHuman();
    theGame.set_player(person, 0);
    Player computer("Computer");
    computer.setComputer();
    theGame.set_player(computer, 1);

    // Deal the cards before starting
    theGame.deal();

    //Run the game
    theGame.run();

    //Clean memory
    return 0;
}

/* 
#ifndif
#define blank 
// define macro (constant) 
#endif 
//if not defined
//prevents compiler from defining multiple times
//header guard 
*/
