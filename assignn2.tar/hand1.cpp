#include "hand1.h"
/*************************************************************************************************************************************
** Function: Default constructor
** Description: sets number of cards to 0;
** Parameters: (no arguements)
** Pre-conditions: (no arguements)
** Post-conditions: rank is set to number or Ace, Jack, Queen, or King
*************************************************************************************************************************************/
Hand::Hand(){
    n_cards = 0;
    cards = nullptr;
    //Call Deck class to get copy of card class
    //take first 7 of card and give to human 
    //take next 7 and give to computer
    //replace given cards with 0?
    
}


/*************************************************************************************************************************************
** Function: Copy constructor
** Description: Tells program how to copy object
** Parameters: const Hand& old_deck
** Pre-conditions: const Hand& old_deck
** Post-conditions: none
*************************************************************************************************************************************/
/*Hand::Hand(const Hand& old_deck){
    cout << "Copy constructor!\n";
    this->n_cards = old_deck.n_cards;
    delete [] cards;
    cards = new Card[this->n_cards];
    for(int i = 0; i<n_cards; i++) {
        cards[i] = old_deck.cards[i];
    }
} */

/*************************************************************************************************************************************
** Function: Assignment Operator
** Description: Tells program how to copy object
** Parameters: const Hand& old_deck
** Pre-conditions: const Hand& old_deck
** Post-conditions: return *this
*************************************************************************************************************************************/
/*Hand& Hand::operator=(const Hand& old_deck){
    cout << "AOO!\n";
    if(this != &old_deck){
        delete [] cards;
        this-> n_cards = old_deck.n_cards;
        cards = new Card[this->n_cards];

        for(int i = 0; i<n_cards; i++) {
            cards[i] = old_deck.cards[i];
        }
    }
    return *this;
} */

/*************************************************************************************************************************************
** Function: addCard
** Description: adds card to new Card array
** Parameters: Card card
** Pre-conditions: Card object
** Post-conditions: Card array is given new card for each time run
*************************************************************************************************************************************/
void Hand::addCard(Card card)
{
    Card* newCards = new Card[++n_cards];
    newCards[n_cards-1] = Card(card.get_rank(),card.get_suit());
    for(int i = 0; i<n_cards-1; i++) {
        newCards[i] = cards[i];
    }
    if (n_cards > 1)
        delete [] cards;
    cards = newCards;
    //cards[n_cards-1].print();

} // End of =()
/*************************************************************************************************************************************
** Function: removeCard
** Description: removes card 
** Parameters: int cardIndex
** Pre-conditions: int
** Post-conditions: card is removed from array
*************************************************************************************************************************************/
void Hand::removeCard(int cardIndex){
    if ( n_cards > 1 ) {
    	Card* newCards = new Card[n_cards-1];
        int j = 0;
    	for(int i = 0; i<n_cards; i++) {
          	if ( i != cardIndex ) {
        		newCards[j++] = cards[i];
            }
    	}
        cards = newCards;
    }
    if ( n_cards > 1) 
        delete [] cards;

} // End of =()

/*************************************************************************************************************************************
** Function: getCard
** Description: returns card
** Parameters: int cardIndex
** Pre-conditions: int
** Post-conditions: return reCard
*************************************************************************************************************************************/
Card Hand::getCard(int cardIndex)
{
    Card reCard(cards[cardIndex].get_rank(),cards[cardIndex].get_suit());
    reCard.print();
    return reCard;

} 

/*************************************************************************************************************************************
** Function: print()
** Description: The card array is printed
** Parameters: none
** Pre-conditions: card array has been declared
** Post-conditions: card array is printed
*************************************************************************************************************************************/
void Hand::print()
{
    for(int i = 0; i<n_cards; i++) {
        cout << i+1 << ". ";
        cards[i].print();
    }

} // End of print()



/*************************************************************************************************************************************
** Function: get_cardrank()
** Description: The card array is printed
** Parameters: none
** Pre-conditions: card array has been declared
** Post-conditions: card array is printed
*************************************************************************************************************************************/
string Hand::get_cardrank(int x){
    string rank;
    rank = cards[x].getrankstr();
    return rank;
} // End of 

/*************************************************************************************************************************************
** Function: get_cardsuit()
** Description: The card array is printed
** Parameters: none
** Pre-conditions: card array has been declared
** Post-conditions: card array is printed
*************************************************************************************************************************************/
string Hand::get_cardsuit(int x){
    string suit;
    suit = cards[x].getsuitstr();
    return suit;
} // End of 

/*************************************************************************************************************************************
** Function: numberofcards()
** Description: Returns number of cards
** Parameters: none
** Pre-conditions: n_cards has been declares
** Post-conditions: number of cards is given
*************************************************************************************************************************************/
int Hand::numberofcards() {
    return this->n_cards;
}

/*************************************************************************************************************************************
** Function: Deconstructor
** Description: Card array is destroyed
** Parameters: none
** Pre-conditions: none
** Post-conditions: Delete from stack
*************************************************************************************************************************************/
Hand::~Hand() {
    //cout << "Hand Destructor!\n";
    if (n_cards)
        delete [] cards;
}





