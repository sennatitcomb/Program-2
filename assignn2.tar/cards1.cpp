#include "cards1.h"
/*************************************************************************************************************************************
** Function: Card() Default constructor
** Description: initalizes variables
** Parameters: (no arguements)
** Pre-conditions: (no arguements)
** Post-conditions: suit and rank are set to 0
*************************************************************************************************************************************/
Card::Card(){
    suit = 0;
    rank = 0;
} 
/*************************************************************************************************************************************
** Function: Non-Default constructor
** Description: sets variables
** Parameters: int rank, int suit
** Pre-conditions: int, int
** Post-conditions: sets variables
*************************************************************************************************************************************/
Card::Card(int rank, int suit) {
    this->suit = suit;
    this->rank = rank;
    //set member values 
}

/*************************************************************************************************************************************
** Function: set_suit()
** Description: sets suit of card
** Parameters: int x
** Pre-conditions: int
** Post-conditions: suit of card is set
*************************************************************************************************************************************/
void Card::set_suit(int x) {
    if (x >= 0 && x <=3) {
        suit = x;
    }
    
}
/*************************************************************************************************************************************
** Function: getsuitstr
** Description: sets suit to actual name
** Parameters: (no arguements)
** Pre-conditions: (no arguements)
** Post-conditions: suit is set to Diamonds, Clubs, Hearts, or Spades
*************************************************************************************************************************************/
string Card::getsuitstr() {
    if (suit == 1) {
            return "Diamonds";
        }else if (suit == 2) {
            return "Clubs";
        }else if (suit == 3) {
            return "Hearts";
        }else {
            return "Spades";
        }
}

/*************************************************************************************************************************************
** Function: getrankstr
** Description: sets rank to actual name
** Parameters: (no arguements)
** Pre-conditions: (no arguements)
** Post-conditions: rank is set to number or Ace, Jack, Queen, or King
*************************************************************************************************************************************/
string Card::getrankstr() {
    if (rank == 1) {
        return "Ace";
    } else if (rank == 11) {
        return "Jack";
    } else if (rank == 12) {
        return "Queen";
    } else if (rank == 13) {
        return "King";
    } else {
        return to_string(rank);
    }
}
/*************************************************************************************************************************************
** Function: print
** Description: prints rank and suit
** Parameters: (no arguements)
** Pre-conditions: (no arguements)
** Post-conditions: prints rank of suit
*************************************************************************************************************************************/
void Card::print()
{
    cout << getrankstr() << " of " << getsuitstr() << endl;

} // End of print()

/*************************************************************************************************************************************
** Function: set_rank
** Description: sets rank
** Parameters: int y
** Pre-conditions: int
** Post-conditions: rank of card is set 
*************************************************************************************************************************************/
void Card::set_rank(int y) {
    rank = y;
}

/*************************************************************************************************************************************
** Function: get_rank
** Description: returns rank
** Parameters: (no arguements)
** Pre-conditions: (no arguements)
** Post-conditions: return this-> rank
*************************************************************************************************************************************/
int Card::get_rank(){
    return this->rank;
}
/*************************************************************************************************************************************
** Function: get_suit
** Description: returns suit
** Parameters: (no arguements)
** Pre-conditions: (no arguements)
** Post-conditions: return this-> suit
*************************************************************************************************************************************/
int Card::get_suit() {
//here you are going into cards class and calling function
    return this-> suit;
    
} 

/*************************************************************************************************************************************
** Function: matches
** Description: checks to see if cards match
** Parameters: Card card
** Pre-conditions: Card
** Post-conditions: return true or false
*************************************************************************************************************************************/
bool Card::matches(Card card) {
    if (rank == card.rank || suit == card.suit) {
        return true;
    }else {
        return false;
    }
}