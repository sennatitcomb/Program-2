#ifndef PLAYER1_H
#define PLAYER1_H

#include <iostream>
#include <stdlib.h>
#include <string>
#include <cmath>
#include <cstring>
#include <ctime>
#include <fstream>
#include <algorithm>
#include "hand1.h"

using namespace std;

class Player {
  private:
    Hand hand;
    string name;
    bool humanFlag;
  public:
    Player();
    Player(string name);
    string getName();
    void addCard(Card card);
    void printHand();
    bool isHuman();
    bool isComputer();
    void setHuman();
    void setComputer();
    int numberofcards();
    string get_rank(int);
    string get_suit(int);
    Card getCard(int cardIndex);
    void removeCard(int cardIndex);
  // must have constructors, destructor, accessor methods, and mutator methods

};

#endif
