#include "game1.h"

/*************************************************************************************************************************************
** Function: Non-default constructor
** Description: sets Deck of cards
** Parameters: Deck& aDeck
** Pre-conditions: Deck
** Post-conditions: cards is initalized
*************************************************************************************************************************************/
Game::Game(Deck& aDeck){
    this->cards = aDeck; 
}

/*************************************************************************************************************************************
** Function: Destructor
** Description: destroys objects
** Parameters: (no arguements)
** Pre-conditions: (no arguements)
** Post-conditions: Delete from stack
*************************************************************************************************************************************/
Game::~Game(){
    //cout << "Game Destructor" << endl;
    //unless there is new, don't delete
} 

/*************************************************************************************************************************************
** Function: get_cards
** Description: Accessor
** Parameters: (no arguements)
** Pre-conditions: (no arguements)
** Post-conditions: return cards
*************************************************************************************************************************************/
Deck Game::get_cards() {
     return this->cards;
}

/*************************************************************************************************************************************
** Function: set_cards
** Description: Mutator 
** Parameters: Deck& aDeck
** Pre-conditions: Deck
** Post-conditions: aDeck is given to cards
*************************************************************************************************************************************/
void Game::set_cards(Deck& aDeck) {
    this->cards = aDeck;
}

/*************************************************************************************************************************************
** Function: get_player
** Description: Accessor
** Parameters: int aPlayerIdx
** Pre-conditions: int
** Post-conditions: player is returned
*************************************************************************************************************************************/
Player Game::get_player(int aPlayerIdx) {
    return this->players[aPlayerIdx];
}

/*************************************************************************************************************************************
** Function: set_player
** Description: Mutator
** Parameters: Player aPlayer, int aPlayerIdx
** Pre-conditions: Player, int
** Post-conditions: specified player is set
*************************************************************************************************************************************/
void Game::set_player(Player aPlayer, int aPlayerIdx) {
    this->players[aPlayerIdx] = aPlayer;
}

/*************************************************************************************************************************************
** Function: deal
** Description: cards are dealt to each player
** Parameters: (no arguements)
** Pre-conditions: (no arguements)
** Post-conditions: each player has a hand
*************************************************************************************************************************************/
void Game::deal() {
    this->cards.shuffle();
    //this->cards.printdeck();
    //this->cards.printTopCard(); 
    for (int i = 0; i < 7; ++i) { //constant, remove card from bottom 
        this->players[0].addCard(this->cards.topcard());
        this->players[1].addCard(this->cards.topcard());
    } 

    //cout << endl << this->players[0].getName() << " hand:" << endl;
   // this->players[0].printHand();
    //cout << endl << this->players[1].getName() << " hand:" << endl;;
    //this->players[1].printHand(); 
}

/*************************************************************************************************************************************
** Function: run
** Description: Card is chosen to be put on pile
** Parameters: (no arguements)
** Pre-conditions: (no arguements)
** Post-conditions: Card must be valid, valid cards are sent to play game
*************************************************************************************************************************************/
void Game::run() {
    int x;
    bool play = true;
    while (play) {
        cout << "Please enter the number of the card you wish to play or enter 0 to draw a card or 99 to quit." << endl;
        this->cards.printTopCard(); 
        players[0].printHand();
        cin >> x;
        if (x == 0) {
            this->players[0].addCard(this->cards.topcard());
            players[0].printHand();
        } else if (x == 99) {
            break;
        }else {
            if(validcard(0,x) == true) {
                if (playgame(0, x) == true) {
                    //this->cards.printTopCard(); 
                    computerturn();
                }else {
                    cout << "Your card did not match! Please choose again or take a card." << endl;
                }
            } else {
                cout << "Invalid input" << endl;
            }
        } 
    }
}

/*************************************************************************************************************************************
** Function: validcard
** Description: checks if card is within hand
** Parameters: int x
** Pre-conditions: int
** Post-conditions: returns true or false
*************************************************************************************************************************************/
bool Game::validcard(int aPlayerIdx, int x) {
    if ( (x < players[0].numberofcards()) || (x == players[0].numberofcards())) {
        return true;
    } else {
        return false;
    }
}

/*************************************************************************************************************************************
** Function: addCard
** Description: adds Card to computer deck
** Parameters: none
** Pre-conditions: none
** Post-conditions: Card is given to computer hand
*************************************************************************************************************************************/
void Game::addCard() {
    //cout << "Your card did not match so a card has been placed in your hand." << endl;
    this->players[1].addCard(this->cards.topcard()); 
    //players[1].printHand();
}

/*************************************************************************************************************************************
** Function: computerturn
** Description: this plays for the computer
** Parameters: none
** Pre-conditions: none
** Post-conditions: nothing b/c void
*************************************************************************************************************************************/
void Game::computerturn() {
    cout << "Computer Plays" << endl;
    bool hasfound = false;
    while (hasfound == false) {
        for (int y = 0; y < players[1].numberofcards(); y++) {
            if(playgame(1, y) == true) {
                hasfound = true;
            }
        }
        if (hasfound == false) {
            addCard();
        }
    }
}


/*************************************************************************************************************************************
** Function: playgame
** Description: Chosen card is compared to topcard and if valid becomes new topcard
** Parameters: int x
** Pre-conditions: int
** Post-conditions: New card is placed on top
*************************************************************************************************************************************/
bool Game::playgame(int aPlayerIdx, int x) {
    if (validcard(aPlayerIdx, x) == true) {
            Card theCard = players[aPlayerIdx].getCard(x-1);
            Card topCard = cards.copyCard();
        if ( theCard.matches(topCard) ) {
            //theCard.print();
            cards.putTop(theCard);
            //cout << endl << this->players[aPlayerIdx].getName() << " hand:" << endl;;
            //players[aPlayerIdx].printHand();
            return true;
        } else {
            //theCard.print();
            return false;
        }
    }else {
        cout << "Invalid input" << endl;
        return false;
    }
}

/*void Game::winner() {
    if () {
    }
}*/