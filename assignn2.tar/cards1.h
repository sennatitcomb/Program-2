#ifndef CARD1_H
#define CARD1_H

#include <iostream>
#include <stdlib.h>
#include <string>
#include <cmath>
#include <cstring>
#include <ctime>
#include <fstream>
#include <algorithm>

using namespace std;

class Card {
  private:
    int rank;  // Should be in the range 0-12.
    int suit;  // Should be in the range 0-3.

  public:
    Card(); // Default constructor (no arguements)
    Card(int rank, int suit); //Non-default constructor 

    int get_suit(); //Accessor
    void set_suit(int); //Mutator
    string getsuitstr();
    string getrankstr();
    int get_rank();
    void set_rank(int);
    void print();
    bool matches(Card);
};


#endif
