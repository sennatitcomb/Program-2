#ifndef GAME1_H
#define GAME1_H

#include <iostream>
#include <stdlib.h>
#include <string>
#include <cmath>
#include <cstring>
#include <ctime>
#include <fstream>
#include <algorithm>
#include "deck1.h"
#include "player1.h"
#include "cards1.h"

using namespace std;

class Game {
  private:
    Deck cards;
    Player players[2];
  public:
    Game(Deck& aDeck);
    ~Game();
    Deck get_cards(); 
    void set_cards(Deck& aDeck);
    Player get_player(int aPlayerIdx);
    void set_player(Player aPlayer, int aPlayerIdx);
    void deal();
    void run();
    bool validcard(int aPlayerIdx, int);
    bool playgame(int aPlayerIdx, int);
    void computerturn();
    void addCard();
};

#endif
