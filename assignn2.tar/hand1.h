#ifndef HAND1_H
#define HAND1_H

#include <iostream>
#include <stdlib.h>
#include <string>
#include <cmath>
#include <cstring>
#include <ctime>
#include <fstream>
#include <algorithm>
#include "cards1.h"
#include "deck1.h"

using namespace std;

class Hand {
  private:
    Card* cards;
    int n_cards;  // Number of cards in the hand.
  public:
    Hand(); // Default constructor (no arguements)
    Hand(int, int); //Non-default constructor 
    string get_cardrank(int); //Accessor
    string get_cardsuit(int);
    void set_hand(int); //Mutator
   // Hand(const Hand&);
   // Hand& operator= (const Hand&);
    void addCard(Card card);
    void print();
    ~Hand();
    int numberofcards();
    void removeCard(int cardIndex);
    Card getCard(int cardIndex);
};

#endif
